from django.db import models

class City(models.Model):
    name = models.CharField(max_length=100, default='?')
    state = models.CharField(max_length=100, default='?')
    co2 = models.IntegerField(default='000')
    so2 = models.IntegerField(default='000')
    pm25 = models.IntegerField(default='000')
    pm10 = models.IntegerField(default='000')
    no2 = models.IntegerField(default='000')
    AQI = models.IntegerField(default='000')
    windDirection = models.IntegerField(default='000')
    temp = models.IntegerField(default='000')
    humidity = models.IntegerField(default='000')