from django_tables2 import SingleTableView

from .models import City
from .tables import CityTable

from django.shortcuts import render
from django.http import HttpResponseRedirect

from .forms import NameForm
from .forms import NamesForm
from .forms import HoursForm

import matplotlib.pyplot as plt 
import numpy as np
import io
import urllib, base64


class CityListView(SingleTableView):
    model = City
    table_class = CityTable
    template_name = 'data/cities.html'

def pie_chart1(request):
    labels = []
    data = []

    if request.method == 'POST':

        form = NameForm(request.POST)

        if form.is_valid():
            city_name = form.cleaned_data['city_name']

            city = City.objects.get(name=city_name)
            labels.append("PM2.5")
            data.append(city.pm25)
            labels.append("PM10")
            data.append(city.pm10)
            labels.append("Co2")
            data.append(city.co2)
            labels.append("So2")
            data.append(city.so2)
            labels.append("No2")
            data.append(city.no2)

    else:
        form = NameForm()

    return render(request, 'data/pie_chart1.html', {
        'labels': labels,
        'data': data,
        'form': form
    })

def pie_chart2(request):
    labels = []
    data = []

    if request.method == 'POST':

        form = NameForm(request.POST)

        if form.is_valid():
            city_name = form.cleaned_data['city_name']

            city = City.objects.get(name=city_name)
            labels.append("So2")
            data.append(city.so2)
            labels.append("No2")
            data.append(city.no2)

    else:
        form = NameForm()

    return render(request, 'data/pie_chart1.html', {
        'labels': labels,
        'data': data,
        'form': form
    })

def line_chart1(request):
    x = []
    y = []

    queryset = City.objects.all()
    for city in queryset:
        x.append(city.pm25)
        y.append(city.windDirection)


    return render(request, 'data/line_chart1.html', {
        'x': x,
        'y': y,
    })

def line_chart2(request):
    labels = []
    data = []
    label = []

    if request.method == 'POST':

        form = HoursForm(request.POST)

        if form.is_valid():
            city_hour1 = form.cleaned_data['city_hour1']
            city_hour2 = form.cleaned_data['city_hour1'] + "Hour2"
            city_hour3 = form.cleaned_data['city_hour1'] + "Hour3"
            city_hour4 = form.cleaned_data['city_hour1'] + "Hour4"
            city_hour5 = form.cleaned_data['city_hour1'] + "Hour5"
            city_hour6 = form.cleaned_data['city_hour1'] + "Hour6"
            city_attr = form.cleaned_data['city_attr']

            city1 = City.objects.get(name=city_hour1)
            city2 = City.objects.get(name=city_hour2)
            city3 = City.objects.get(name=city_hour3)
            city4 = City.objects.get(name=city_hour4)
            city5 = City.objects.get(name=city_hour5)
            city6 = City.objects.get(name=city_hour6)

            co2 = "co2"
            so2 = "so2"
            pm25 = "pm25"
            pm10 = "pm10"
            no2 = "no2"
            AQI = "AQI"

            if city_attr == co2:
                newData1 = city1.co2
                newData2 = city2.co2
                newData3 = city3.co2
                newData4 = city4.co2
                newData5 = city5.co2
                newData6 = city6.co2

            if city_attr == so2:
                newData1 = city1.so2
                newData2 = city2.so2
                newData3 = city3.so2
                newData4 = city4.so2
                newData5 = city5.so2
                newData6 = city6.so2

            if city_attr == pm25:
                newData1 = city1.pm25
                newData2 = city2.pm25
                newData3 = city3.pm25
                newData4 = city4.pm25
                newData5 = city5.pm25
                newData6 = city6.pm25

            if city_attr == pm10:
                newData1 = city1.pm10
                newData2 = city2.pm10
                newData3 = city3.pm10
                newData4 = city4.pm10
                newData5 = city5.pm10
                newData6 = city6.pm10

            if city_attr == no2:
                newData1 = city1.no2
                newData2 = city2.no2
                newData3 = city3.no2
                newData4 = city4.no2
                newData5 = city5.no2
                newData6 = city6.no2

            if city_attr == AQI:
                newData1 = city1.AQI
                newData2 = city2.AQI
                newData3 = city3.AQI
                newData4 = city4.AQI
                newData5 = city5.AQI
                newData6 = city6.AQI

            labels.append(city_hour1)
            data.append(newData1)
            labels.append(city_hour2)
            data.append(newData2)
            labels.append(city_hour3)
            data.append(newData3)
            labels.append(city_hour4)
            data.append(newData4)
            labels.append(city_hour5)
            data.append(newData5)
            labels.append(city_hour6)
            data.append(newData6)
            label.append(city_attr)


    else:
        form = HoursForm()

    return render(request, 'data/line_chart2.html', {
        'labels': labels,
        'data': data,
        'label': label,
        'form': form
    })

def bar_chart1(request):
    labels = []
    data = []

    if request.method == 'POST':

        form = NamesForm(request.POST)

        if form.is_valid():
            city_name1 = form.cleaned_data['city_name1']
            city_name2 = form.cleaned_data['city_name2']
            city_name3 = form.cleaned_data['city_name3']
            city_name4 = form.cleaned_data['city_name4']
            city_name5 = form.cleaned_data['city_name5']

            city1 = City.objects.get(name=city_name1)
            labels.append(city_name1)
            data.append(city1.co2)

            city2 = City.objects.get(name=city_name2)
            labels.append(city_name2)
            data.append(city2.co2)

            city3 = City.objects.get(name=city_name3)
            labels.append(city_name3)
            data.append(city3.co2)

            city4 = City.objects.get(name=city_name4)
            labels.append(city_name4)
            data.append(city4.co2)

            city5 = City.objects.get(name=city_name5)
            labels.append(city_name5)
            data.append(city5.co2)

    else:
        form = NamesForm()

    return render(request, 'data/bar_chart1.html', {
        'labels': labels,
        'data': data,
        'form': form
    })

def bar_chart2(request):
    labels = []
    data = []

    if request.method == 'POST':

        form = NameForm(request.POST)

        if form.is_valid():
            city_name1 = form.cleaned_data['city_name']
            city_name2 = form.cleaned_data['city_name'] + "Hour2"
            city_name3 = form.cleaned_data['city_name'] + "Hour3"
            city_name4 = form.cleaned_data['city_name'] + "Hour4"
            city_name5 = form.cleaned_data['city_name'] + "Hour5"
            city_name6 = form.cleaned_data['city_name'] + "Hour6"

            city1 = City.objects.get(name=city_name1)
            city2 = City.objects.get(name=city_name2)
            city3 = City.objects.get(name=city_name3)
            city4 = City.objects.get(name=city_name4)
            city5 = City.objects.get(name=city_name5)
            city6 = City.objects.get(name=city_name6)


            tempNums = [city1.so2,city2.so2,city3.so2,city4.so2,city5.so2,city6.so2]

            maxNum = max(tempNums)

            labels.append('so2')
            data.append(maxNum)

            tempNums.clear()
            tempNums = [city1.pm25,city2.pm25,city3.pm25,city4.pm25,city5.pm25,city6.pm25]

            maxNum = max(tempNums)

            labels.append('pm25')
            data.append(maxNum)

            tempNums.clear()
            tempNums = [city1.pm10,city2.pm10,city3.pm10,city4.pm10,city5.pm10,city6.pm10]

            maxNum = max(tempNums)

            labels.append('pm10')
            data.append(maxNum)

            tempNums.clear()
            tempNums = [city1.no2,city2.no2,city3.no2,city4.no2,city5.no2,city6.no2]

            maxNum = max(tempNums)

            labels.append('no2')
            data.append(maxNum)

            tempNums.clear()
            tempNums = [city1.AQI,city2.AQI,city3.AQI,city4.AQI,city5.AQI,city6.AQI]

            maxNum = max(tempNums)

            labels.append('AQI')
            data.append(maxNum)

    else:
        form = NameForm()

    return render(request, 'data/bar_chart2.html', {
        'labels': labels,
        'data': data,
        'form': form
    })

def box_plot1(request):

    if request.method == 'POST':

        form = HoursForm(request.POST)

        if form.is_valid():

            city_hour1 = form.cleaned_data['city_hour1']
            city_hour2 = form.cleaned_data['city_hour1'] + "Hour2"
            city_hour3 = form.cleaned_data['city_hour1'] + "Hour3"
            city_hour4 = form.cleaned_data['city_hour1'] + "Hour4"
            city_hour5 = form.cleaned_data['city_hour1'] + "Hour5"
            city_hour6 = form.cleaned_data['city_hour1'] + "Hour6"
            city_attr = form.cleaned_data['city_attr']

            city1 = City.objects.get(name=city_hour1)
            city2 = City.objects.get(name=city_hour2)
            city3 = City.objects.get(name=city_hour3)
            city4 = City.objects.get(name=city_hour4)
            city5 = City.objects.get(name=city_hour5)
            city6 = City.objects.get(name=city_hour6)

            co2 = "co2"
            so2 = "so2"
            pm25 = "pm25"
            pm10 = "pm10"
            no2 = "no2"
            AQI = "AQI"

            if city_attr == co2:
                newData1 = city1.co2
                newData2 = city2.co2
                newData3 = city3.co2
                newData4 = city4.co2
                newData5 = city5.co2
                newData6 = city6.co2

            if city_attr == so2:
                newData1 = city1.so2
                newData2 = city2.so2
                newData3 = city3.so2
                newData4 = city4.so2
                newData5 = city5.so2
                newData6 = city6.so2

            if city_attr == pm25:
                newData1 = city1.pm25
                newData2 = city2.pm25
                newData3 = city3.pm25
                newData4 = city4.pm25
                newData5 = city5.pm25
                newData6 = city6.pm25

            if city_attr == pm10:
                newData1 = city1.pm10
                newData2 = city2.pm10
                newData3 = city3.pm10
                newData4 = city4.pm10
                newData5 = city5.pm10
                newData6 = city6.pm10

            if city_attr == no2:
                newData1 = city1.no2
                newData2 = city2.no2
                newData3 = city3.no2
                newData4 = city4.no2
                newData5 = city5.no2
                newData6 = city6.no2

            if city_attr == AQI:
                newData1 = city1.AQI
                newData2 = city2.AQI
                newData3 = city3.AQI
                newData4 = city4.AQI
                newData5 = city5.AQI
                newData6 = city6.AQI

            # Creating dataset 
            np.random.seed(10) 
            data = [newData1,newData2,newData3,newData4,newData5,newData6]
          
            fig = plt.figure(figsize =(10, 7)) 
          
            # Creating plot 
            plt.boxplot(data) 
          
            # show plot 
            plt.show()

    else:
        form = NameForm()

    return render(request, 'data/box_plot1.html', {
        'form': form
        })


def charts(request):
    return render(request, 'data/charts.html')
