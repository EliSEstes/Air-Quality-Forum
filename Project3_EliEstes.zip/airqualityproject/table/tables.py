import django_tables2 as tables

