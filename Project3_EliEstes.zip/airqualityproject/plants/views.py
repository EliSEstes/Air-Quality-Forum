from django_tables2 import SingleTableView

from .models import Plant
from .tables import PlantTable

class PlantListView(SingleTableView):
    model = Plant
    table_class = PlantTable
    template_name = 'plants/plantstable.html'