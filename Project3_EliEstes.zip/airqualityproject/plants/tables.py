import django_tables2 as tables
from .models import Plant

class PlantTable(tables.Table):
    class Meta:
        model = Plant
        template_name = "django_tables2/bootstrap.html"
        fields = ("name", )