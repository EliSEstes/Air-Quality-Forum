from django.db import models

class Plant(models.Model):
    name = models.CharField(max_length=100, default='?')
    city = models.CharField(max_length=100, default='?')
    state = models.CharField(max_length=100, default='?')
    co2 = models.IntegerField(default='000')
    so2 = models.IntegerField(default='000')
    noX = models.IntegerField(default='000')
    hg = models.IntegerField(default='000')