from django.apps import AppConfig


class forumConfig(AppConfig):
    name = 'forum'
