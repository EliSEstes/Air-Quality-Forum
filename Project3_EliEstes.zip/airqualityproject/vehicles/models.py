from django.db import models

class Vehicle(models.Model):
    make = models.CharField(max_length=100, default='?')
    model = models.CharField(max_length=100, default='?')
    co2 = models.IntegerField(default='000')
    ghg = models.IntegerField(default='000')