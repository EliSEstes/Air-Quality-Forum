from django_tables2 import SingleTableView

from .models import Vehicle
from .tables import VehicleTable

class VehicleListView(SingleTableView):
    model = Vehicle
    table_class = VehicleTable
    template_name = 'vehicles/vehicles.html'