import django_tables2 as tables
from .models import Vehicle

class VehicleTable(tables.Table):
    class Meta:
        model = Vehicle
        template_name = "django_tables2/bootstrap.html"
        fields = ("name", )